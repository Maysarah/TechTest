<?php $__env->startSection('content'); ?>
    <div class="mt-5">
        <h1>Edit Article</h1>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('articles.update', $article['id'])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" class="form-control" name="title" id="title" value="<?php echo e(old('title', $article['title'])); ?>">
            </div>
            <div class="form-group">
                <label for="content">Content:</label>
                <textarea class="form-control" name="content" id="content"><?php echo e(old('content', $article['content'])); ?></textarea>
            </div>
            <div class="form-group">
                <label for="images">Upload New Images:</label>
                <input type="file" class="form-control" name="images[]" id="images" multiple>
            </div>

            <div class="form-group mt-4">
                <label>Existing Images:</label>
                <?php if(isset($article['images']) && count($article['images']) > 0): ?>
                    <div class="row">
                        <?php $__currentLoopData = $article['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3 mb-3">
                                <div class="card">
                                    <img src="<?php echo e(Storage::disk('s3')->url($image['path'])); ?>" class="card-img-top" alt="Article Image">
                                    <div class="card-body">
                                        <input type="checkbox" name="images_to_delete[]" value="<?php echo e($image['id']); ?>">
                                        <label for="images_to_delete[]"> Delete this image</label>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <p>No images uploaded yet.</p>
                <?php endif; ?>
            </div>

            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/articles/edit.blade.php ENDPATH**/ ?>