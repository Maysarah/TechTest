<?php $__env->startSection('content'); ?>
    <div class="mt-5">
        <h1><?php echo e($article->title); ?></h1>
        <p><?php echo e($article->content); ?></p>

        <?php if($article->images->isNotEmpty()): ?>
            <div class="mt-4">
                <h2>Images:</h2>
                <div class="row">
                    <?php $__currentLoopData = $article->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 mb-3">
                            <img src="<?php echo e(Storage::disk('s3')->url($image->path)); ?>" class="img-fluid" alt="Article Image">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>

        <a href="<?php echo e(route('articles.index')); ?>" class="btn btn-secondary">Back to Articles</a>
        <a href="<?php echo e(route('articles.edit', $article->id)); ?>" class="btn btn-warning">Edit</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/articles/show.blade.php ENDPATH**/ ?>